package creational.singleton.enumt;

public enum EasySingleton {
	INSTANCE;
}
