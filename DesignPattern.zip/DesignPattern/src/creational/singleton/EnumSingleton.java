package creational.singleton;

public class EnumSingleton {
	
}
