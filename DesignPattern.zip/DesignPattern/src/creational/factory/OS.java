package creational.factory;

public interface OS {
	void spec();
}
