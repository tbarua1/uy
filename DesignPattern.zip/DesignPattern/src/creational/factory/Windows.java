package creational.factory;

public class Windows implements OS {

	@Override
	public void spec() {
		// TODO Auto-generated method stub
		System.out.println(" i am about to die");
	}

}
