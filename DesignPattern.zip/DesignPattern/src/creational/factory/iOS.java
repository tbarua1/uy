package creational.factory;

public class iOS implements OS {

	@Override
	public void spec() {
		// TODO Auto-generated method stub
		System.out.println("Secure and Closed Plateform  OS");

	}

}
