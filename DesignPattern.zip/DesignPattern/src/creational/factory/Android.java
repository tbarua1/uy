package creational.factory;

public class Android implements OS{

	@Override
	public void spec() {
		// TODO Auto-generated method stub
		System.out.println("Most Populer OS");
	}

}
