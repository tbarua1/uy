package creational.abstract_factory;

public class Red implements Color {


	@Override
	public void filled() {
		// TODO Auto-generated method stub
		System.out.println("fill Red color");
	}

}
