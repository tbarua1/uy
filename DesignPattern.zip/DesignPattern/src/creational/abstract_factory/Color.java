package creational.abstract_factory;

public interface Color {
void filled();
}
