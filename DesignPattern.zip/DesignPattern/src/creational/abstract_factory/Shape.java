package creational.abstract_factory;

public interface Shape {
	void draw();
}
