package creational.abstract_factory;

public class Blue implements Color {

	@Override
	public void filled() {
		// TODO Auto-generated method stub
System.out.println("Fill Blue Color");
	}

}
