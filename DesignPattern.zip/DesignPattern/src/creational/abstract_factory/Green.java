package creational.abstract_factory;

public class Green implements Color {

	@Override
	public void filled() {
		// TODO Auto-generated method stub
System.out.println("fill Green Color");
	}

}
