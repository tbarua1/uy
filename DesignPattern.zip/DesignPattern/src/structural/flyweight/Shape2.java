package structural.flyweight;

public interface Shape2 {
void draw();
}
