package structural.adapter.one;

public interface MediaPlayer {
	public void play(String audioType, String fileName);
}
