package structural.adapter;

public class PilotPen {
	public void mark(String s){
		System.out.println("i am from Pilot Pen");
	}

}
