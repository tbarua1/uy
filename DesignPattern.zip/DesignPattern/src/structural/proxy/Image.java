package structural.proxy;

public interface Image {
public void displayImage();
//public void display();
}
