package structural.decorator;

public interface Shape1 {
public void draw();
}
