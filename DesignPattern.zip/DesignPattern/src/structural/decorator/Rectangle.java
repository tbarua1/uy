package structural.decorator;

public class Rectangle implements Shape1{

	@Override
	public void draw() {
		// TODO Auto-generated method stub
	System.out.println("i am at Rectangle");	
	}

}
