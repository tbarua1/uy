package structural.decorator;

public class Circle implements Shape1 {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
System.out.println("i am inside Circle");
	}

}
