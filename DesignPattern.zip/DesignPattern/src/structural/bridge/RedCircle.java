package structural.bridge;

public class RedCircle implements DrawAPI {

	@Override
	public void drawCircle(int radius, int x, int y) {
		// TODO Auto-generated method stub
System.out.println(radius+" Draw Red Color Circle "+x+" "+y);
	}

}
