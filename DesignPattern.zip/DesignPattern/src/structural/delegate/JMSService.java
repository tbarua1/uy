package structural.delegate;

public class JMSService implements BusinessService {

	
	public void doProcessing() {
		// TODO Auto-generated method stub
		System.out.println("Processing task by invoking JMS Service");
	}

}
