package structural.delegate;

public class EJBService implements BusinessService {

	public void doProcessing() {
		// TODO Auto-generated method stub
		System.out.println("Processing task by invoking EJB Service");
	}

}
