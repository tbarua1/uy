package structural.delegate;

public interface BusinessService {
	public void doProcessing();

	
}
