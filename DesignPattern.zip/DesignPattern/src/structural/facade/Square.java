package structural.facade;

public class Square implements Shape0 {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
System.out.println("i am at Square");
	}

}
