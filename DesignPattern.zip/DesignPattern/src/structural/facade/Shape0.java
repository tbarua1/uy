package structural.facade;

public interface Shape0 {
public void draw();
}
