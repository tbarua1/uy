package structural.facade;

public class Rectangle implements Shape0 {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
System.out.println("i am inside Rectangle ");
	}

}
