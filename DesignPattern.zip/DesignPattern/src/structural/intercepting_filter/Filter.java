package structural.intercepting_filter;

public interface Filter {
	public void execute(String request);
}
