package structural.front_controller;

public class HomeView {
	public void show(){
	      System.out.println("Displaying Home Page");
	   }
}
