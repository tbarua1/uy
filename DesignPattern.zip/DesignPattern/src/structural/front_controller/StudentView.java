package structural.front_controller;

public class StudentView {
	public void show(){
	      System.out.println("Displaying Student View Page");
	   }
}
