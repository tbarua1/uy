package structural.service_locator;

public interface Service {
	public String getName();
	   public void execute();
}
