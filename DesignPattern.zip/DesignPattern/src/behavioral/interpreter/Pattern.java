package behavioral.interpreter;


public interface Pattern {
	
	
	public String conversion(String exp);

}
