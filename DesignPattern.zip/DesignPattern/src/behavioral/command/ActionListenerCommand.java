package behavioral.command;


public interface ActionListenerCommand {
	
	public void execute();

}
