package behavioral.iterator;

public interface Container {
    public Iterator getIterator();  
}
